# JAOXIT V1 — projeto Android

Projeto inicial em Kotlin para abrir no Android Studio.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `JAOXIT_V1_Android`.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Este projeto é um painel demonstrativo de preferências. Não injeta código no Free Fire,
não implementa Aimbot/ESP e não oferece nem promete anti-ban.
