package com.jaoxit.v1

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 16)
    private val red = Color.rgb(235, 35, 48)
    private val white = Color.WHITE
    private val muted = Color.rgb(175, 175, 185)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showSplash()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(24, 36, 24, 24)
        setBackgroundColor(bg)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 10, 8, 10)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(white)
            setBackgroundColor(red)
            setOnClickListener { action() }
        }

    private fun showSplash() {
        val layout = base()
        layout.gravity = Gravity.CENTER
        val logo = text("JAOXIT", 38f, red, true)
        layout.addView(logo)
        layout.addView(text("V1  •  RED EDITION", 14f, muted, true))
        layout.addView(text("PAINEL DE CONFIGURAÇÕES", 12f, white))
        val enter = button("ENTRAR") { showPanel() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = 34
        layout.addView(enter, lp)
        setContentView(layout)
        logo.alpha = 0f
        logo.animate().alpha(1f).setDuration(900).start()
        logo.animate().scaleX(1.05f).scaleY(1.05f).setDuration(900).start()
    }

    private fun showPanel() {
        val layout = base()
        layout.gravity = Gravity.TOP
        layout.addView(text("🔥 JAOXIT V1", 28f, red, true))
        layout.addView(text("RED EDITION  •  ANDROID", 12f, muted))
        layout.addView(section("MIRA E SENSIBILIDADE"))
        val profile = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Precisão", "Capa", "Equilibrado")
            )
        }
        layout.addView(profile, LinearLayout.LayoutParams(-1, -2))
        layout.addView(section("SENSIBILIDADE"))
        val value = text("Sensibilidade: 85", 16f, white, true)
        layout.addView(value)
        val seek = SeekBar(this).apply {
            max = 200
            progress = 85
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    value.text = "Sensibilidade: $p"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        layout.addView(seek)
        layout.addView(section("GELO"))
        val ice = Switch(this).apply {
            text = "Preferência de gelo invertido"
            setTextColor(white)
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
        }
        layout.addView(ice)
        layout.addView(section("OBSERVAÇÃO"))
        layout.addView(text(
            "Este app salva apenas preferências visuais nesta tela. Ele não modifica o Free Fire, não oferece Aimbot/ESP e não promete proteção contra banimento.",
            13f, muted
        ))
        val back = button("VOLTAR À ABERTURA") { showSplash() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = 24
        layout.addView(back, lp)
        val scroll = ScrollView(this).apply { addView(layout) }
        setContentView(scroll)
    }

    private fun section(label: String): View {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 18, 0, 6)
        }
        wrapper.addView(text(label, 15f, red, true))
        return wrapper
    }
}
